# OIPP
OIPP (Online integration platform for projects is the application which is a knowledge platform mainly focuses about the details of the projects and the education content along with the community (user generated content).
