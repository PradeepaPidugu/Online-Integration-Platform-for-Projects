package com.codeinfinity.oipp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SearchProjectsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_projects);
    }
}